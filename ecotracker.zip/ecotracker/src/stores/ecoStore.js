import { defineStore } from 'pinia'

export const useEcoStore = defineStore('eco', {
  state: () => ({
    actions: [], // lista das ações sustentáveis
    xp: 0 // pontos verdes
  }),
  actions: {
    addAction(action) {
      this.actions.push(action)
      this.xp += 10 // cada ação dá 10 XP
    },
    deleteAction(id) {
      this.actions = this.actions.filter(a => a.id !== id)
    }
  }
})
