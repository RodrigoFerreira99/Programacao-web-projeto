<template>
  <div>
    <h1>🌱 EcoTracker</h1>
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/actions">Ações</router-link> |
      <router-link to="/stats">Estatísticas</router-link> |
      <router-link to="/about">Sobre</router-link>
    </nav>
    <router-view></router-view>
  </div>
</template>
