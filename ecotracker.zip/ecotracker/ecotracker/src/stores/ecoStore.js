import { defineStore } from 'pinia'

export const useEcoStore = defineStore('eco', {
  state: () => ({
    actions: [],
    xp: 0,
    level: 1
  }),

  getters: {
    totalActions: (state) => state.actions.length,
    nextLevelXP: (state) => state.level * 100
  },

  actions: {
    //Carregar ações do mock server
    async loadActions() {
      const res = await fetch('http://localhost:3000/actions')
      this.actions = await res.json()
    },

    //Adicionar nova ação (e enviar para o mock server)
    async addAction(action) {
      const res = await fetch('http://localhost:3000/actions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(action)
      })
      const newAction = await res.json()
      this.actions.push(newAction)

      // lógica de gamificação
      this.xp += 10
      if (this.xp >= this.nextLevelXP) {
        this.level++
        this.xp = 0
      }
    },

    // Eliminar ação (mock server + local)
    async deleteAction(id) {
      await fetch(`http://localhost:3000/actions/${id}`, {
        method: 'DELETE'
      })
      this.actions = this.actions.filter(a => a.id !== id)
    }
  }
})
