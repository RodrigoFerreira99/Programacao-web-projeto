<template>
  <h2>Página Home</h2>
</template>
