<template>
  <div>
    <h2>Ações sustentáveis</h2>

    <input v-model="nova" placeholder="Nova ação" />
    <button @click="adicionar">Adicionar</button>

    <ul>
      <li v-for="a in eco.actions" :key="a.id">
        {{ a.titulo }} - {{ a.data }}
        <button @click="remover(a.id)">❌</button>
      </li>
    </ul>

    <p>Total de XP: {{ eco.xp }}</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useEcoStore } from '../stores/ecoStore'

const eco = useEcoStore()
const nova = ref('')

const API_URL = 'http://localhost:3000/actions'

async function carregarAcoes() {
  const res = await fetch(API_URL)
  eco.actions = await res.json()
}

async function adicionar() {
  if (nova.value.trim() === '') return
  const novaAcao = {
    titulo: nova.value,
    data: new Date().toISOString().slice(0, 10)
  }
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(novaAcao)
  })
  const criada = await res.json()
  eco.addAction(criada)
  nova.value = ''
}

async function remover(id) {
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' })
  eco.deleteAction(id)
}

onMounted(carregarAcoes)
</script>
